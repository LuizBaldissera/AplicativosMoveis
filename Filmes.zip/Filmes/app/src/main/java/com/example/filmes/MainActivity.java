package com.example.filmes;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText txtNome;
    private EditText txtNota;
    private EditText txtAno;
    private Button btnSalvar;
    private Button btnLista;
    private FilmeDAO filmeDao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializa os componentes da UI
        txtNome = findViewById(R.id.txtNome);
        txtNota = findViewById(R.id.txtNota);
        txtAno = findViewById(R.id.txtAno);
        btnSalvar = findViewById(R.id.btnSalvar);
        btnLista = findViewById(R.id.btnLista);

        // Inicializa o banco de dados e o DAO
        FilmeDatabase filmeDatabase = FilmeDatabase.getDatabase(this);
        filmeDao = filmeDatabase.filmeDao();

        // Configura o listener do botão Salvar
        btnSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                salvarFilme();
            }
        });

        // Configura o listener do botão Lista
        btnLista.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirListarFilmeActivity();
            }
        });
    }

    private void salvarFilme() {
        // Obtém os dados dos EditText
        String nome = txtNome.getText().toString();
        String notaString = txtNota.getText().toString();
        String anoString = txtAno.getText().toString();

        // Valida os dados
        if (nome.isEmpty() || notaString.isEmpty() || anoString.isEmpty()) {
            Toast.makeText(this, "Preencha todos os campos!", Toast.LENGTH_SHORT).show();
            return;
        }

        double nota;
        int ano;
        try {
            nota = Double.parseDouble(notaString);
            ano = Integer.parseInt(anoString);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Nota e Ano devem ser números!", Toast.LENGTH_SHORT).show();
            return;
        }

        // Cria um novo objeto Filme
        Filme filme = new Filme(nome, nota, ano);

        // Insere o filme no banco de dados em uma nova thread
        new Thread(new Runnable() {
            @Override
            public void run() {
                filmeDao.insert(filme);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(MainActivity.this, "Filme salvo!", Toast.LENGTH_SHORT).show();
                        limparCampos();
                    }
                });
            }
        }).start();
    }

    private void limparCampos() {
        txtNome.setText("");
        txtNota.setText("");
        txtAno.setText("");
    }

    private void abrirListarFilmeActivity() {
        Intent intent = new Intent(this, ListarFilmeActivity.class);
        startActivity(intent);
    }
}