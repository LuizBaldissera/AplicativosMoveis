package com.example.filmes;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities = {Filme.class}, version = 1)
public abstract class FilmeDatabase extends RoomDatabase {

    public abstract FilmeDAO filmeDao();

    private static volatile FilmeDatabase INSTANCE;

    public static FilmeDatabase getDatabase(final Context context) {
        if (INSTANCE == null) {
            synchronized (FilmeDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                                    FilmeDatabase.class, "filme_database")
                            .build();
                }
            }
        }
        return INSTANCE;
    }
}