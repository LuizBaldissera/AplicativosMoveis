package com.example.filmes;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "filmes")
public class Filme {

    @PrimaryKey(autoGenerate = true)
    public int id;

    @ColumnInfo(name = "nome")
    public String nome;

    @ColumnInfo(name = "nota")
    public double nota;

    @ColumnInfo(name = "ano")
    public int ano;

    public Filme(String nome, double nota, int ano) {
        this.nome = nome;
        this.nota = nota;
        this.ano = ano;
    }
}