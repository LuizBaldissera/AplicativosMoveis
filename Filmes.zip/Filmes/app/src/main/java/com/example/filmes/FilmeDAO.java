package com.example.filmes;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface FilmeDAO {
    @Query("SELECT * FROM filmes")
    List<Filme> getAll();

    @Query("SELECT * FROM filmes WHERE id = :id")
    Filme getById(int id);

    @Insert
    void insert(Filme filme);

    @Update
    void update(Filme filme);

    @Delete
    void delete(Filme filme);
}
