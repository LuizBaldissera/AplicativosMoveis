package com.example.filmes;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class ListarFilmeActivity extends AppCompatActivity {

    private ListView listFilme;
    private Button btnVoltar;
    private FilmeDAO filmeDao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listar_filme);

        // Inicializa os componentes da UI
        listFilme = findViewById(R.id.listFilme);
        btnVoltar = findViewById(R.id.btnVoltar);

        // Inicializa o banco de dados e o DAO
        FilmeDatabase filmeDatabase = FilmeDatabase.getDatabase(this);
        filmeDao = filmeDatabase.filmeDao();

        // Carrega os filmes do banco de dados
        carregarFilmes();

        // Configura o listener do botão Voltar
        btnVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // Fecha a activity atual e volta para a anterior
            }
        });
    }

    private void carregarFilmes() {
        // Busca os filmes no banco de dados em uma nova thread
        new Thread(new Runnable() {
            @Override
            public void run() {
                List<Filme> filmes = filmeDao.getAll();
                List<String> filmesFormatados = new ArrayList<>();

                for (Filme filme : filmes) {
                    String filmeFormatado = "Nome: " + filme.nome + "\n" +
                            "Nota: " + filme.nota + "\n" +
                            "Ano: " + filme.ano;
                    filmesFormatados.add(filmeFormatado);
                }

                // Atualiza a UI na thread principal
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        // Cria um ArrayAdapter para exibir os filmes na ListView
                        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                                ListarFilmeActivity.this,
                                android.R.layout.simple_list_item_1,
                                filmesFormatados
                        );

                        // Define o adapter na ListView
                        listFilme.setAdapter(adapter);
                    }
                });
            }
        }).start();
    }
}