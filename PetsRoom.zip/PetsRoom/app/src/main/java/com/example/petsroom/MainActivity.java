package com.example.petsroom;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText txtCpf, txtNome, txtTel;
    private Button btnAdd, btnIrLista; //Added btnIrLista
    private PetDatabase petDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI elements
        txtCpf = findViewById(R.id.txtCpf);
        txtNome = findViewById(R.id.txtNome);
        txtTel = findViewById(R.id.txtTel);
        btnAdd = findViewById(R.id.Salvar);
        btnIrLista = findViewById(R.id.btnIrLista);

        // Get the database instance
        petDatabase = DatabaseClient.getInstance(getApplicationContext()).getAppDatabase();

        // Set click listener for the add button
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addPet();
            }
        });
        // Set click listener for the "Ir para Lista" button
        btnIrLista.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ListarPetsActivity.class);
                startActivity(intent);
            }
        });
    }

    private void addPet() {
        // Get data from EditTexts
        String cpf = txtCpf.getText().toString().trim();
        String nome = txtNome.getText().toString().trim();
        String tel = txtTel.getText().toString().trim();

        // Validate data (you might want to add more validation)
        if (cpf.isEmpty() || nome.isEmpty() || tel.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        // Create a new Pet object
        Pet pet = new Pet(cpf, nome, tel);

        // Insert the pet into the database in a background thread
        new Thread(new Runnable() {
            @Override
            public void run() {
                PetDaoRoom petDao = petDatabase.petDaoRoom();
                petDao.insert(pet);

                // Show a success message on the UI thread
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(MainActivity.this, "Pet added successfully", Toast.LENGTH_SHORT).show();
                        // Clear the input fields
                        txtCpf.setText("");
                        txtNome.setText("");
                        txtTel.setText("");
                    }
                });
            }
        }).start();
    }
}