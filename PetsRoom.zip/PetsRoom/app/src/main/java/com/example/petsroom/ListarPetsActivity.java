package com.example.petsroom;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class ListarPetsActivity extends AppCompatActivity {

    private ListView petsListView;
    private PetDatabase petDatabase;
    private Button btnIrMain; //Added the button

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listar_pets);

        petsListView = findViewById(R.id.PetsList);
        btnIrMain = findViewById(R.id.btnIrMain); //Initialize the button
        petDatabase = DatabaseClient.getInstance(getApplicationContext()).getAppDatabase();

        loadPets();

        btnIrMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ListarPetsActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }

    private void loadPets() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                PetDaoRoom petDao = petDatabase.petDaoRoom();
                List<Pet> pets = petDao.getAllPets();

                // Update UI on the main thread
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        updateUIWithPets(pets);
                    }
                });
            }
        }).start();
    }

    private void updateUIWithPets(List<Pet> pets) {
        if (pets != null && !pets.isEmpty()) {
            ArrayList<String> petStrings = new ArrayList<>();
            for (Pet pet : pets) {
                petStrings.add("CPF: " + pet.getCpfDono() + " | Nome: " + pet.getNomePet() + " | Telefone: " + pet.getTelefoneDono());
            }

            ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, petStrings);
            petsListView.setAdapter(adapter);
        } else {
            Log.d("ListarPetsActivity", "No pets found in the database");
            // Optionally, you can show a message to the user in the UI that no pets were found.
        }
    }
}