package com.example.petsroom;


import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.io.Serializable;

@Entity(tableName = "pet")
public class Pet implements Serializable {

    @PrimaryKey
    @NonNull
    @ColumnInfo(name = "cpfDono")
    private String cpfDono; // Primary Key

    @ColumnInfo(name = "nomePet")
    private String nomePet;

    @ColumnInfo(name = "telefoneDono")
    private String telefoneDono;

    public Pet(String cpfDono, String nomePet, String telefoneDono) {
        this.cpfDono = cpfDono;
        this.nomePet = nomePet;
        this.telefoneDono = telefoneDono;
    }

    public String getCpfDono() {
        return cpfDono;
    }

    public void setCpfDono(String cpfDono) {
        this.cpfDono = cpfDono;
    }

    public String getNomePet() {
        return nomePet;
    }

    public void setNomePet(String nomePet) {
        this.nomePet = nomePet;
    }

    public String getTelefoneDono() {
        return telefoneDono;
    }

    public void setTelefoneDono(String telefoneDono) {
        this.telefoneDono = telefoneDono;
    }

    @Override
    public String toString() {
        return "Animal{" +
                "cpfDono='" + cpfDono + '\'' +
                ", nomePet='" + nomePet + '\'' +
                ", telefoneDono='" + telefoneDono + '\'' +
                '}';
    }
}
