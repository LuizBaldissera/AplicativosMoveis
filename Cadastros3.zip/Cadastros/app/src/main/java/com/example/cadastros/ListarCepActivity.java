package com.example.cadastros;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ListarCepActivity extends AppCompatActivity {

    private EditText cepEditText;
    private TextView txtLogradouro, txtComplemento, txtBairro, txtLocalidade, txtUf, txtCep;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listar_cep);

        // Inicializar as Views
        cepEditText = findViewById(R.id.txtCep);
        txtLogradouro = findViewById(R.id.txtLog);
        txtComplemento = findViewById(R.id.txtComp);
        txtBairro = findViewById(R.id.txtBai);
        txtUf = findViewById(R.id.txtCid);
        txtCep = findViewById(R.id.txtCep);


        // Configurar o botão
        Button botaoCEP = findViewById(R.id.BuscarCEP);
        if (botaoCEP == null){
            Log.e("Botao", "Não encontrou botão com id CEP");
            return;
        }
        botaoCEP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("Botao", "Clicou no botão");
                if (cepEditText == null){
                    Log.d("Botao", "erro ao pegar cep_edit_text");
                    return;
                }
                String cep = cepEditText.getText().toString();
                Log.d("CEP", "CEP digitado: " + cep);

                if (cep.isEmpty()){
                    Log.d("Botao", "cep_edit_text vazio");
                    Toast.makeText(ListarCepActivity.this, "O campo de CEP deve ser preenchido", Toast.LENGTH_LONG).show();
                    return;
                }
                buscarEndereco(cep);
            }
        });
    }

    private void buscarEndereco(String cep) {
        Log.d("buscarEndereco", "método chamado");
        Log.d("CEP", "CEP passado para o metodo buscar endereco: " + cep);

        RetrofitConfig retrofitConfig = new RetrofitConfig();
        ViaCEPApi viaCEPApi = retrofitConfig.getViaCEPApi();
        Call<ViaCEPResponse> call = viaCEPApi.getEndereco(cep);

        call.enqueue(new Callback<ViaCEPResponse>() {
            @Override
            public void onResponse(Call<ViaCEPResponse> call, Response<ViaCEPResponse> response) {
                if (response.isSuccessful()) {
                    ViaCEPResponse endereco = response.body();
                    Log.d("ViaCEP", "Endereço encontrado: " + endereco.toString());

                    // Preencher os TextViews
                    if(endereco == null){
                        txtLogradouro.setText("Logradouro: " + endereco.getLogradouro());
                        txtComplemento.setText("Complemento: " + endereco.getComplemento());
                        txtBairro.setText("Bairro: " + endereco.getBairro());
                        txtLocalidade.setText("Localidade: " + endereco.getLocalidade());
                        txtUf.setText("UF: " + endereco.getUf());
                        txtCep.setText("CEP: " + endereco.getCep());
                    } else {
                        Toast.makeText(ListarCepActivity.this, "CEP não encontrado", Toast.LENGTH_LONG).show();
                    }
                } else {
                    Log.e("ViaCEP", "Erro na requisição: " + response.code());
                    Toast.makeText(ListarCepActivity.this, "Erro na requisição", Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<ViaCEPResponse> call, Throwable t) {
                Log.e("ViaCEP", "Erro na requisição: " + t.getMessage());
                Toast.makeText(ListarCepActivity.this, "Erro de conexão", Toast.LENGTH_LONG).show();
            }
        });
    }
}